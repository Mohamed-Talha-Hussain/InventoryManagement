import { products, sections, type Product, type InsertProduct, type Section, type InsertSection } from "@shared/schema";

export interface IStorage {
  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProductsBySection(section: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  searchProducts(query: string, section?: string): Promise<Product[]>;
  
  // Section operations
  getAllSections(): Promise<Section[]>;
  getSection(id: string): Promise<Section | undefined>;
  createSection(section: InsertSection): Promise<Section>;
  updateSection(id: string, updates: Partial<InsertSection>): Promise<Section | undefined>;
  deleteSection(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private sections: Map<string, Section>;
  private currentId: number;

  constructor() {
    this.products = new Map();
    this.sections = new Map();
    this.currentId = 1;
    
    // Initialize with default sections
    const defaultSections = [
      { id: 'all', name: 'All Sections', description: 'Overview of all inventory items', icon: 'Warehouse' },
      { id: 'fridge-a', name: 'Fridge A', description: 'Refrigerated items in section A', icon: 'Snowflake' },
      { id: 'fridge-b', name: 'Fridge B', description: 'Refrigerated items in section B', icon: 'Snowflake' },
      { id: 'rack-a', name: 'Rack A', description: 'Shelf storage in rack A', icon: 'Layers' },
      { id: 'rack-b', name: 'Rack B', description: 'Shelf storage in rack B', icon: 'Layers' },
      { id: 'bakery', name: 'Bakery', description: 'Fresh baked goods and bread', icon: 'Croissant' },
      { id: 'produce', name: 'Produce', description: 'Fresh fruits and vegetables', icon: 'Apple' },
      { id: 'deli', name: 'Deli', description: 'Deli meats and prepared foods', icon: 'Ham' }
    ];
    
    defaultSections.forEach(section => {
      this.sections.set(section.id, {
        ...section,
        dateAdded: new Date()
      });
    });
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductsBySection(section: string): Promise<Product[]> {
    if (section === 'all') {
      return this.getAllProducts();
    }
    return Array.from(this.products.values()).filter(
      (product) => product.section === section,
    );
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentId++;
    const product: Product = {
      ...insertProduct,
      id,
      dateAdded: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) {
      return undefined;
    }

    const updated: Product = {
      ...existing,
      ...updates,
    };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async searchProducts(query: string, section?: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    let products = Array.from(this.products.values());

    if (section && section !== 'all') {
      products = products.filter(p => p.section === section);
    }

    return products.filter(
      (product) =>
        product.name.toLowerCase().includes(lowerQuery) ||
        product.category.toLowerCase().includes(lowerQuery)
    );
  }

  // Section operations
  async getAllSections(): Promise<Section[]> {
    return Array.from(this.sections.values());
  }

  async getSection(id: string): Promise<Section | undefined> {
    return this.sections.get(id);
  }

  async createSection(insertSection: InsertSection): Promise<Section> {
    const section: Section = {
      ...insertSection,
      dateAdded: new Date(),
    };
    this.sections.set(section.id, section);
    return section;
  }

  async updateSection(id: string, updates: Partial<InsertSection>): Promise<Section | undefined> {
    const existing = this.sections.get(id);
    if (!existing) {
      return undefined;
    }

    const updated: Section = {
      ...existing,
      ...updates,
    };
    this.sections.set(id, updated);
    return updated;
  }

  async deleteSection(id: string): Promise<boolean> {
    // Don't allow deleting the 'all' section
    if (id === 'all') {
      return false;
    }
    
    // Move products from deleted section to 'all' section
    const productsInSection = Array.from(this.products.values()).filter(p => p.section === id);
    productsInSection.forEach(product => {
      this.products.set(product.id, { ...product, section: 'all' });
    });
    
    return this.sections.delete(id);
  }
}

export const storage = new MemStorage();

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { StatsCards } from "@/components/stats-cards";
import { ProductsTable } from "@/components/products-table";
import { ProductModal } from "@/components/product-modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Search, Download, Plus } from "lucide-react";
import type { Product, Section } from "@shared/schema";

export default function InventoryPage() {
  const [currentSection, setCurrentSection] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const { toast } = useToast();

  const { data: products = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/products", currentSection, searchTerm],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (currentSection !== "all") params.set("section", currentSection);
      if (searchTerm) params.set("search", searchTerm);
      
      const response = await fetch(`/api/products?${params}`);
      if (!response.ok) throw new Error("Failed to fetch products");
      return response.json();
    },
  });

  const { data: sections = [] } = useQuery({
    queryKey: ["/api/sections"],
    queryFn: async () => {
      const response = await fetch("/api/sections");
      if (!response.ok) throw new Error("Failed to fetch sections");
      return response.json();
    },
  });

  const currentSectionData = sections.find((s: Section) => s.id === currentSection) || { 
    id: 'all', 
    name: 'All Sections', 
    description: 'Overview of all inventory items' 
  };

  const sortedProducts = [...products].sort((a, b) => {
    switch (sortBy) {
      case "expiry":
        return new Date(a.expiry).getTime() - new Date(b.expiry).getTime();
      case "category":
        return a.category.localeCompare(b.category);
      case "section":
        return a.section.localeCompare(b.section);
      default:
        return a.name.localeCompare(b.name);
    }
  });

  const handleExportCSV = () => {
    if (products.length === 0) {
      toast({
        title: "No Data",
        description: "No products to export",
        variant: "destructive",
      });
      return;
    }

    const headers = ["Product Name", "Category", "Section", "Expiry Date", "Status", "Days Until Expiry"];
    const csvContent = [
      headers.join(","),
      ...products.map((product: Product) => {
        const sectionName = sections.find((s: Section) => s.id === product.section)?.name || product.section;
        const today = new Date();
        const expiry = new Date(product.expiry);
        const diffDays = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        let status = "Fresh";
        let daysText = `${diffDays} days left`;
        
        if (diffDays < 0) {
          status = "Expired";
          daysText = `${Math.abs(diffDays)} days ago`;
        } else if (diffDays <= 3) {
          status = "Expiring Soon";
          daysText = diffDays === 0 ? "Expires today" : `${diffDays} days left`;
        }

        return [
          `"${product.name}"`,
          `"${product.category}"`,
          `"${sectionName}"`,
          `"${new Date(product.expiry).toLocaleDateString()}"`,
          `"${status}"`,
          `"${daysText}"`
        ].join(",");
      })
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `inventory-${currentSection}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "CSV file has been downloaded",
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar 
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
        onAddProduct={() => setIsAddModalOpen(true)}
        onExport={handleExportCSV}
      />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-slate-900">{currentSectionData.name}</h2>
              <p className="text-sm text-slate-500">{currentSectionData.description}</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              {searchTerm && (
                <div className="px-3 py-1 bg-primary text-white text-xs rounded-full">
                  {products.length} filtered
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <StatsCards products={sortedProducts} />
          
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Products</h3>
              <div className="flex items-center space-x-2">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Sort by Name</SelectItem>
                    <SelectItem value="expiry">Sort by Expiry</SelectItem>
                    <SelectItem value="category">Sort by Category</SelectItem>
                    <SelectItem value="section">Sort by Section</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => setIsAddModalOpen(true)} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </div>
            </div>

            <ProductsTable 
              products={sortedProducts}
              isLoading={isLoading}
              onEdit={setEditingProduct}
              onRefresh={refetch}
              onAddProduct={() => setIsAddModalOpen(true)}
            />
          </div>
        </div>
      </main>

      <ProductModal
        isOpen={isAddModalOpen || !!editingProduct}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingProduct(null);
        }}
        product={editingProduct}
        onSuccess={() => {
          refetch();
          setIsAddModalOpen(false);
          setEditingProduct(null);
        }}
      />
    </div>
  );
}

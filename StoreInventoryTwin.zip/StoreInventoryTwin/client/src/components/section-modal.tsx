import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertSectionSchema } from "@shared/schema";
import type { Section, InsertSection } from "@shared/schema";

interface SectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  section?: Section | null;
  onSuccess: () => void;
}

const availableIcons = [
  { value: "Warehouse", label: "Warehouse" },
  { value: "Snowflake", label: "Snowflake (Fridge)" },
  { value: "Layers", label: "Layers (Rack)" },
  { value: "Croissant", label: "Croissant (Bakery)" },
  { value: "Apple", label: "Apple (Produce)" },
  { value: "Ham", label: "Ham (Deli)" },
  { value: "Package", label: "Package" },
  { value: "ShoppingCart", label: "Shopping Cart" },
  { value: "Truck", label: "Truck" },
  { value: "Store", label: "Store" }
];

export function SectionModal({ isOpen, onClose, section, onSuccess }: SectionModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!section;

  const form = useForm<InsertSection>({
    resolver: zodResolver(insertSectionSchema),
    defaultValues: {
      id: "",
      name: "",
      description: "",
      icon: "",
    },
  });

  useEffect(() => {
    if (section) {
      form.reset({
        id: section.id,
        name: section.name,
        description: section.description,
        icon: section.icon,
      });
    } else {
      form.reset({
        id: "",
        name: "",
        description: "",
        icon: "",
      });
    }
  }, [section, form]);

  const mutation = useMutation({
    mutationFn: async (data: InsertSection) => {
      if (isEditing) {
        return await apiRequest("PATCH", `/api/sections/${section.id}`, data);
      } else {
        return await apiRequest("POST", "/api/sections", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sections"] });
      toast({
        title: "Success",
        description: `Section ${isEditing ? "updated" : "created"} successfully`,
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "create"} section`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertSection) => {
    mutation.mutate(data);
  };

  const handleClose = () => {
    if (!mutation.isPending) {
      onClose();
      form.reset();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Section" : "Add New Section"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Section ID</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., storage-room-1" 
                      {...field} 
                      disabled={isEditing}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Section Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter section name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter section description" 
                      {...field} 
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="icon"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Icon</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an icon" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {availableIcons.map((icon) => (
                        <SelectItem key={icon.value} value={icon.value}>
                          {icon.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex space-x-3 pt-4">
              <Button
                type="submit"
                className="flex-1"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Saving..." : isEditing ? "Save Changes" : "Add Section"}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={handleClose}
                disabled={mutation.isPending}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
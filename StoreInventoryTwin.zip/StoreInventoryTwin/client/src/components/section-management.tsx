import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, Plus, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { SectionModal } from "./section-modal";
import type { Section } from "@shared/schema";

interface SectionManagementProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SectionManagement({ isOpen, onClose }: SectionManagementProps) {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sections = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/sections"],
    queryFn: async () => {
      const response = await fetch("/api/sections");
      if (!response.ok) throw new Error("Failed to fetch sections");
      return response.json();
    },
    enabled: isOpen,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/sections/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Success",
        description: "Section deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete section",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (section: Section) => {
    if (section.id === 'all') {
      toast({
        title: "Cannot Delete",
        description: "The 'All Sections' section cannot be deleted",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Are you sure you want to delete "${section.name}"? All products in this section will be moved to 'All Sections'.`)) {
      deleteMutation.mutate(section.id);
    }
  };

  const handleClose = () => {
    setIsAddModalOpen(false);
    setEditingSection(null);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Section Management
            </DialogTitle>
          </DialogHeader>

          <div className="flex flex-col space-y-4 overflow-hidden">
            <div className="flex justify-between items-center">
              <p className="text-sm text-slate-600">
                Manage store sections and their configurations
              </p>
              <Button onClick={() => setIsAddModalOpen(true)} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Section
              </Button>
            </div>

            <div className="flex-1 overflow-auto border rounded-lg">
              {isLoading ? (
                <div className="p-8 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-slate-500">Loading sections...</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50">
                      <TableHead>Section ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Icon</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sections.map((section: Section) => (
                      <TableRow key={section.id} className="hover:bg-slate-50">
                        <TableCell>
                          <code className="bg-slate-100 px-2 py-1 rounded text-xs">
                            {section.id}
                          </code>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-slate-900">{section.name}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-slate-500 max-w-xs truncate">
                            {section.description}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{section.icon}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={section.id === 'all' ? 'default' : 'secondary'}>
                            {section.id === 'all' ? 'System' : 'Custom'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingSection(section)}
                              className="text-primary hover:text-primary/80"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            {section.id !== 'all' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(section)}
                                className="text-red-600 hover:text-red-700"
                                disabled={deleteMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <SectionModal
        isOpen={isAddModalOpen || !!editingSection}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingSection(null);
        }}
        section={editingSection}
        onSuccess={() => {
          refetch();
          setIsAddModalOpen(false);
          setEditingSection(null);
        }}
      />
    </>
  );
}
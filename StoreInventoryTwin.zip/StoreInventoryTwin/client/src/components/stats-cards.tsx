import { Package, CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import type { Product } from "@shared/schema";

interface StatsCardsProps {
  products: Product[];
}

export function StatsCards({ products }: StatsCardsProps) {
  const stats = products.reduce(
    (acc, product) => {
      acc.total++;
      
      const today = new Date();
      const expiry = new Date(product.expiry);
      const diffDays = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays < 0) {
        acc.expired++;
      } else if (diffDays <= 3) {
        acc.expiringSoon++;
      } else {
        acc.fresh++;
      }
      
      return acc;
    },
    { total: 0, fresh: 0, expiringSoon: 0, expired: 0 }
  );

  const cards = [
    {
      title: "Total Products",
      value: stats.total,
      icon: Package,
      bgColor: "bg-blue-50",
      iconColor: "text-primary",
    },
    {
      title: "Fresh Items",
      value: stats.fresh,
      icon: CheckCircle,
      bgColor: "bg-green-50",
      iconColor: "text-green-600",
    },
    {
      title: "Expiring Soon",
      value: stats.expiringSoon,
      icon: AlertTriangle,
      bgColor: "bg-orange-50",
      iconColor: "text-orange-600",
    },
    {
      title: "Expired",
      value: stats.expired,
      icon: XCircle,
      bgColor: "bg-red-50",
      iconColor: "text-red-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <div key={card.title} className="bg-white rounded-xl p-6 border border-slate-200">
            <div className="flex items-center">
              <div className={`p-2 ${card.bgColor} rounded-lg`}>
                <Icon className={`${card.iconColor} h-6 w-6`} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-slate-600">{card.title}</p>
                <p className="text-2xl font-semibold text-slate-900">{card.value}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

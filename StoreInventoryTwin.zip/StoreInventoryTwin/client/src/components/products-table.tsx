import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Edit, Trash2, Package, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getExpiryStatus, formatDate } from "@/lib/utils";
import type { Product, Section } from "@shared/schema";

interface ProductsTableProps {
  products: Product[];
  isLoading: boolean;
  onEdit: (product: Product) => void;
  onRefresh: () => void;
  onAddProduct: () => void;
}

export function ProductsTable({ products, isLoading, onEdit, onRefresh, onAddProduct }: ProductsTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sections = [] } = useQuery({
    queryKey: ["/api/sections"],
    queryFn: async () => {
      const response = await fetch("/api/sections");
      if (!response.ok) throw new Error("Failed to fetch sections");
      return response.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Success",
        description: "Product deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete product",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (product: Product) => {
    if (window.confirm(`Are you sure you want to delete "${product.name}"?`)) {
      deleteMutation.mutate(product.id);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="mt-2 text-slate-500">Loading products...</p>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="px-6 py-12 text-center">
        <div className="mx-auto w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mb-4">
          <Package className="text-slate-400 h-8 w-8" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 mb-2">No products found</h3>
        <p className="text-slate-500 mb-6">Get started by adding your first product to the inventory.</p>
        <Button onClick={onAddProduct}>
          <Plus className="mr-2 h-4 w-4" />
          Add First Product
        </Button>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead>Product</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Section</TableHead>
            <TableHead>Expiry Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {products.map((product) => {
            const { status, daysText, variant } = getExpiryStatus(product.expiry);
            const sectionName = sections.find((s: Section) => s.id === product.section)?.name || product.section;

            return (
              <TableRow key={product.id} className="hover:bg-slate-50">
                <TableCell>
                  <div className="font-medium text-slate-900">{product.name}</div>
                </TableCell>
                <TableCell>
                  <div className="text-slate-500">{product.category}</div>
                </TableCell>
                <TableCell>
                  <div className="text-slate-500">{sectionName}</div>
                </TableCell>
                <TableCell>
                  <div className="text-slate-900">{formatDate(product.expiry)}</div>
                  <div className="text-xs text-slate-500">{daysText}</div>
                </TableCell>
                <TableCell>
                  <Badge variant={variant}>{status}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEdit(product)}
                      className="text-primary hover:text-primary/80"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(product)}
                      className="text-red-600 hover:text-red-700"
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

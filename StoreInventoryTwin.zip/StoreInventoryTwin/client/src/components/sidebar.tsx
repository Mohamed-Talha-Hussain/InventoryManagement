import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  Warehouse, 
  Snowflake, 
  Layers, 
  Croissant, 
  Apple, 
  Ham,
  Plus,
  Download,
  Settings,
  Package,
  ShoppingCart,
  Truck,
  Store
} from "lucide-react";
import { SectionManagement } from "./section-management";
import type { Section } from "@shared/schema";

const iconMap = {
  Warehouse,
  Snowflake,
  Layers,
  Croissant,
  Apple,
  Ham,
  Package,
  ShoppingCart,
  Truck,
  Store,
};

interface SidebarProps {
  currentSection: string;
  onSectionChange: (section: string) => void;
  onAddProduct: () => void;
  onExport: () => void;
}

export function Sidebar({ currentSection, onSectionChange, onAddProduct, onExport }: SidebarProps) {
  const [isSectionManagementOpen, setIsSectionManagementOpen] = useState(false);

  const { data: sections = [], isLoading } = useQuery({
    queryKey: ["/api/sections"],
    queryFn: async () => {
      const response = await fetch("/api/sections");
      if (!response.ok) throw new Error("Failed to fetch sections");
      return response.json();
    },
  });

  return (
    <>
      <aside className="w-80 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Warehouse className="text-white h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-slate-900">Digital Twin</h1>
              <p className="text-sm text-slate-500">Inventory System</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-slate-700 uppercase tracking-wide">
                Store Sections
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsSectionManagementOpen(true)}
                className="text-xs text-slate-500 hover:text-slate-700"
              >
                <Settings className="h-3 w-3" />
              </Button>
            </div>
            <nav className="space-y-1">
              {isLoading ? (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mx-auto"></div>
                </div>
              ) : (
                sections.map((section: Section) => {
                  const Icon = iconMap[section.icon as keyof typeof iconMap] || Warehouse;
                  const isActive = currentSection === section.id;
                  
                  return (
                    <Button
                      key={section.id}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-sm font-medium",
                        isActive
                          ? "bg-primary text-white hover:bg-primary/90"
                          : "text-slate-700 hover:bg-slate-100"
                      )}
                      onClick={() => onSectionChange(section.id)}
                    >
                      <Icon className="mr-3 h-4 w-4" />
                      {section.name}
                    </Button>
                  );
                })
              )}
            </nav>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200">
            <h3 className="text-sm font-medium text-slate-700 mb-3 uppercase tracking-wide">
              Quick Actions
            </h3>
            <div className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start text-sm font-medium text-slate-700 hover:bg-slate-100"
                onClick={onAddProduct}
              >
                <Plus className="mr-3 h-4 w-4" />
                Add Product
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-sm font-medium text-slate-700 hover:bg-slate-100"
                onClick={onExport}
              >
                <Download className="mr-3 h-4 w-4" />
                Export CSV
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-sm font-medium text-slate-700 hover:bg-slate-100"
                onClick={() => setIsSectionManagementOpen(true)}
              >
                <Settings className="mr-3 h-4 w-4" />
                Manage Sections
              </Button>
            </div>
          </div>
        </div>
      </aside>

      <SectionManagement
        isOpen={isSectionManagementOpen}
        onClose={() => setIsSectionManagementOpen(false)}
      />
    </>
  );
}

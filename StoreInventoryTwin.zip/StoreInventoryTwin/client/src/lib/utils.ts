import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getExpiryStatus(expiryDate: string) {
  const today = new Date();
  const expiry = new Date(expiryDate);
  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return {
      status: "Expired",
      daysText: `${Math.abs(diffDays)} days ago`,
      variant: "destructive" as const,
    };
  } else if (diffDays <= 3) {
    return {
      status: "Expiring Soon",
      daysText: diffDays === 0 ? "Expires today" : `${diffDays} days left`,
      variant: "secondary" as const,
    };
  } else {
    return {
      status: "Fresh",
      daysText: `${diffDays} days left`,
      variant: "default" as const,
    };
  }
}

export function formatDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

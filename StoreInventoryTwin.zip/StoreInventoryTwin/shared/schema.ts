import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  section: text("section").notNull(),
  expiry: text("expiry").notNull(), // ISO date string
  dateAdded: timestamp("date_added").defaultNow().notNull(),
});

export const sections = pgTable("sections", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  dateAdded: timestamp("date_added").defaultNow().notNull(),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  category: true,
  section: true,
  expiry: true,
});

export const insertSectionSchema = createInsertSchema(sections).pick({
  id: true,
  name: true,
  description: true,
  icon: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type InsertSection = z.infer<typeof insertSectionSchema>;
export type Section = typeof sections.$inferSelect;

// Section configuration type
export interface StoreSection {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export const storeSections: StoreSection[] = [
  { id: 'all', name: 'All Sections', description: 'Overview of all inventory items', icon: 'Warehouse' },
  { id: 'fridge-a', name: 'Fridge A', description: 'Refrigerated items in section A', icon: 'Snowflake' },
  { id: 'fridge-b', name: 'Fridge B', description: 'Refrigerated items in section B', icon: 'Snowflake' },
  { id: 'rack-a', name: 'Rack A', description: 'Shelf storage in rack A', icon: 'Layers' },
  { id: 'rack-b', name: 'Rack B', description: 'Shelf storage in rack B', icon: 'Layers' },
  { id: 'bakery', name: 'Bakery', description: 'Fresh baked goods and bread', icon: 'Croissant' },
  { id: 'produce', name: 'Produce', description: 'Fresh fruits and vegetables', icon: 'Apple' },
  { id: 'deli', name: 'Deli', description: 'Deli meats and prepared foods', icon: 'Ham' }
];
